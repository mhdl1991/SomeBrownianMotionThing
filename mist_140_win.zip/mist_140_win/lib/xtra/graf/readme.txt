The graphic files are available as a seperate archive from

ftp://export.andrew.cmu.edu/angband/Extra/angband-graf.zip
or
ftp://ftp.sunet.se/pub/games/Angband/Extra/angband-graf.zip

Robert Ruehlmann
rr9@angband.org

